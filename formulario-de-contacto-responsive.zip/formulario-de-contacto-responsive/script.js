document.getElementById("contactForm").addEventListener("submit",function(event){
    event.preventDefault();
    alert("formulario enviado exitosamente!!")
});